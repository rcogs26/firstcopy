import $ from 'jquery';
import PageManager from '../page-manager';

export default class Blog extends PageManager {
    loaded(next) {
        $('.addthis_button_pinterest').addClass('fix-pinterest-width');

        next();
    }
}
