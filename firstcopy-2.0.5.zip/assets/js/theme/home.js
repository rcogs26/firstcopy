import PageManager from '../page-manager';
import swatchPreview from './common/swatch-preview';

export default class Home extends PageManager {
    loaded() {
        if (this.context.enableSwatches) {
            swatchPreview();
        }
    }

}
