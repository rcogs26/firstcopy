import $ from 'jquery';
import Cookies from 'js-cookie';

export default function () {
    const categoryView = Cookies.get('catView');

    function switchTo(e) {
        e.preventDefault();
        const listingType = $(this).attr('data-switch');
        Cookies.set('catView', listingType);
        location.reload();
    }

    $('.switcher').on('click', switchTo);

    if (categoryView) {
        $('ul.productGrid').addClass(`view-${categoryView}`);
        $(`.switcher[data-switch="${categoryView}"]`).addClass('current-view');
    } else {
        $('.switcher[data-switch="grid"]').addClass('current-view');
    }
}
