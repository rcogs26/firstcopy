import $ from 'jquery';
import Cookies from 'js-cookie';

export default function (delay, reappear) {
    const nlHide = Cookies.get('nlHide');

    function showNewsletter() {
        if (!nlHide) {
            $('.newsletter-popup, .newsletter-overlay').fadeIn('slow');
        }
    }

    setTimeout(showNewsletter, delay);

    function closePopup(e) {
        e.preventDefault();
        Cookies.set('nlHide', '1', { expires: reappear });
        $('.newsletter-popup, .newsletter-overlay').fadeOut('slow');
    }

    function submitForm(e) {
        e.preventDefault();
        Cookies.set('nlHide', '1', { expires: 999 });
        this.submit();
    }

    $('.newsletter-popup-dismiss').on('click', closePopup);

    $('.newsletter-popup form').on('submit', submitForm);
}
